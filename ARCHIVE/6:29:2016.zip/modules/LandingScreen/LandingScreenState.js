import {Map} from 'immutable';
import {loop, Effects} from 'redux-loop';

// Initialize currentUser vars


// Initialize state
const initialState = Map({

});

// Action types


// Action creators


/**
  *   Reducer
  *
  *   Passed a state and an action. Updates the appropriate section of the state
  *   tree based on that action and returns full state tree.
  *
**/
export default function LandingScreenReducer(state = initialState, action = {}) {
  switch (action.type) {
    
  }

  return state;
}
