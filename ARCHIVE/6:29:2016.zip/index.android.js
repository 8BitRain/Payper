import { AppRegistry } from 'react-native';

import Coincast from './Coincast';

AppRegistry.registerComponent('Coincast', () => Coincast);
